package com.example.service_call

import com.example.service_call.DataClass.*
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT

interface Api_call {
    @GET("todos")
    fun getTodos(): Call<TodoResponse>

 @PUT("todos/1")
    fun getUpdate():Call<Todo>

@DELETE("todos/1")
    fun getDelete():Call<DeleteModel>

    @POST("/todos/add")
    suspend fun addTodo(@Body todo: Todo): Todo
}