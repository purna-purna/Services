package com.example.service_call.DataClass

import com.google.gson.annotations.SerializedName

data class Model(
    @SerializedName("id") val id: Int,
                 @SerializedName("todo")           val todo: String,
                 @SerializedName("completed")       val completed: Boolean,
                 @SerializedName("user_id")      val userId: Int)
